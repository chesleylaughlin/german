
import React from 'react';
export default function Oktoberfest() {
  return (
    <div style={{ padding: '40px' }}>
      <h1>About Oktoberfest</h1>
      <p>Oktoberfest is the world's largest beer festival, held annually in Munich, Germany.</p>
      <p>Enjoy Bavarian food, music, parades, and authentic cultural experiences.</p>
    </div>
  );
}
