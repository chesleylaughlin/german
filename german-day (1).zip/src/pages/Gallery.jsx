
import React from 'react';
export default function Gallery() {
  const images = [
    'https://images.unsplash.com/photo-1603039481261-7a4a7ed2a2b0',
    'https://images.unsplash.com/photo-1601996425159-64b2a0b1d818',
    'https://images.unsplash.com/photo-1505761671935-60b3a7427bad'
  ];
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', justifyContent: 'center', padding: '20px' }}>
      {images.map((img, i) => <img key={i} src={img} alt={`Gallery ${i}`} style={{ width: '300px', borderRadius: '10px' }} />)}
    </div>
  );
}
