
import React from 'react';
export default function History() {
  return (
    <div style={{ padding: '40px' }}>
      <h1>History of Oktoberfest</h1>
      <p>The first Oktoberfest was held in 1810 to celebrate the royal wedding of Crown Prince Ludwig and Princess Therese of Saxony-Hildburghausen.</p>
      <p>Since then, it has evolved into a global celebration of Bavarian culture.</p>
    </div>
  );
}
