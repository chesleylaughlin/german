
import React from 'react';
export default function Contact() {
  return (
    <div style={{ textAlign: 'center', padding: '50px' }}>
      <h1>Contact Us</h1>
      <p>For any inquiries about German Day or Oktoberfest celebrations, reach out at <a href='mailto:info@germanday.com'>info@germanday.com</a>.</p>
    </div>
  );
}
