
import React from 'react';
import { Link, NavLink } from 'react-router-dom';

export default function Navbar(){
  const navClass = ({isActive}) => isActive ? 'text-yellow-600 font-semibold' : 'text-gray-700';
  return (
    <header className="bg-white shadow-sm sticky top-0 z-20">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link to="/" className="text-xl font-extrabold">German Day</Link>
        <nav className="space-x-4">
          <NavLink to="/" className={navClass}>Home</NavLink>
          <NavLink to="/oktoberfest" className={navClass}>Oktoberfest</NavLink>
          <NavLink to="/gallery" className={navClass}>Gallery</NavLink>
          <NavLink to="/history" className={navClass}>History</NavLink>
          <NavLink to="/contact" className={navClass}>Contact</NavLink>
        </nav>
      </div>
    </header>
  );
}
