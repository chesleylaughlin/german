
import React from 'react';

export default function Footer(){
  return (
    <footer className="bg-white border-t">
      <div className="max-w-6xl mx-auto px-6 py-6 text-sm text-gray-600 flex flex-col md:flex-row justify-between">
        <div>© {new Date().getFullYear()} German Day Collective</div>
        <div>Celebrate culture, food, and community</div>
      </div>
    </footer>
  );
}
