
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Oktoberfest from './pages/Oktoberfest';
import Gallery from './pages/Gallery';
import History from './pages/History';
import Contact from './pages/Contact';

function App() {
  return (
    <Router>
      <nav style={{ display: 'flex', gap: '20px', padding: '20px', background: '#f7f7f7' }}>
        <Link to='/'>Home</Link>
        <Link to='/oktoberfest'>Oktoberfest</Link>
        <Link to='/gallery'>Gallery</Link>
        <Link to='/history'>History</Link>
        <Link to='/contact'>Contact</Link>
      </nav>
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/oktoberfest' element={<Oktoberfest />} />
        <Route path='/gallery' element={<Gallery />} />
        <Route path='/history' element={<History />} />
        <Route path='/contact' element={<Contact />} />
      </Routes>
    </Router>
  );
}

export default App;
