# German Day — Oktoberfest
A ready-to-deploy React + Tailwind project (single repo) for the *German Day — Oktoberfest* site.

## What this ZIP contains
- React app (src/) with React Router + Framer Motion + lucide-react icons
- Tailwind CSS setup (basic)
- Unsplash images referenced directly (no copyrighted downloads)
- Ready-to-deploy to Vercel or Netlify

## Quick start (locally)
1. Extract ZIP
2. `cd german-day`
3. `npm install`
4. `npm start`

## Deploy to Vercel
1. Push this repo to GitHub.
2. Sign in to Vercel and import the GitHub repo.
3. Vercel detects React and runs `npm run build` automatically.

---
Hero headline used: **Willkommen to German Day — Experience the Magic of Oktoberfest!**
